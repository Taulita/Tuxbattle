<?php


$histo = array();
$res = mysqli_query($db, "SELECT * from t_histo");
while ($data = mysqli_fetch_assoc($res))
	{
	$histo = $data;
	$ligne = $histo['nom1']. "(".$histo['arme1']." ".$histo['potion1']. " ". $histo['sort1']. ") inflige ".
		$histo['damage']. "pt(s) a ".$histo['nom2']."<br>";
	require('game.phtml');
	}
