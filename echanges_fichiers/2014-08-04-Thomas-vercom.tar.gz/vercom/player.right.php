<?php
$req = "SELECT * FROM t_joueur
		WHERE nom = 'computer'";

		

$res = mysqli_query($db,$req);
$data = mysqli_fetch_assoc($res);


	require("views/player.right.phtml");
	require("sources/confphp/parametres.conf.php");


?>